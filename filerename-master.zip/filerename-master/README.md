# filerename
Renames all files to (name)+(number)
